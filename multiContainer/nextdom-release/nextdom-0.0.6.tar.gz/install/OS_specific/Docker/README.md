## Installation via docker

Voir le projet nextdom-docker pour executer nextdom sur docker.