/**
 * Interface pour nextdom.class.js
 */
//function jeedom() {}

class jeedom extends nextdom {

}

/*
jeedom.prototype = Object.create(nextdom.prototype);
jeedom.prototype.constructor = nextdom;
jeedom.prototype._super = nextdom;
*/