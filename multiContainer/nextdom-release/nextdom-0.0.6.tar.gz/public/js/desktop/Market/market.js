var currentPlugin=null;var filterHiddenSrc=[];var filterCategory='';var filterInstalled=false;var filterNotInstalled=false;var currentSearchValue='';var iconDownloadQueue=[];var pluginsUpdateNeededList=[];$(document).ready(function(){initEvents();refresh(false);});function initEvents(){if(github!='1'){notify('Erreur','Les dépôts GitHub sont désactivés','error');}
$('#market-filter-src button').click(function(){var source=$(this).data('source');if(isActive($(this))){filterHiddenSrc.push(source);setActive($(this),false);}
else{var itemIndex=-1;for(var index=0;index<filterHiddenSrc.length;++index){if(filterHiddenSrc[index]==source){itemIndex=index;}}
if(itemIndex>-1){filterHiddenSrc.splice(itemIndex,1);}
setActive($(this),true);}
updateFilteredList();});$('#market-filter-category').change(function(){var selectedCategory=$("#market-filter-category option:selected").val();if(selectedCategory!=='all'){filterCategory=selectedCategory;}
else{filterCategory='';}
updateFilteredList();});$('#market-filter-installed').click(function(){if(isActive($(this))){filterInstalled=true;setActive($(this),false);if(filterNotInstalled){setActive($('#market-filter-notinstalled'),true);filterNotInstalled=false;}}
else{filterInstalled=false;setActive($(this),true);}
updateFilteredList();});$('#market-filter-notinstalled').click(function(){if(isActive($(this))){filterNotInstalled=true;setActive($(this),false);if(filterInstalled){setActive($('#market-filter-installed'),true);filterInstalled=false;}}
else{filterNotInstalled=false;setActive($(this),true);}
updateFilteredList();});$('#market-search').keyup(function(){currentSearchValue=$(this).val().toLowerCase();updateFilteredList();});$('#refresh-markets').click(function(){refresh(true);});$('#mass-update').click(function(){if(pluginsUpdateNeededList.length>0){currentPlugin=pluginsUpdateNeededList[0];$('#market-modal-title').text(updateStr);var contentHtml='<p>'+updateAllStr+'</p><ul>';for(var pluginIndex=0;pluginIndex<pluginsUpdateNeededList.length;++pluginIndex){contentHtml+='<li>'+pluginsUpdateNeededList[pluginIndex]['name']+'</li>';}
contentHtml+='</ul>';$('#market-modal-content').html(contentHtml);$('#market-modal-valid').text(updateStr);$('#market-modal').modal('show');$('#market-modal-valid').click(function(){updatePlugin(currentPlugin['installedBranchData']['id'],true);});return false;}});}
function isActive(button){var result=false;if(button.hasClass('btn-primary')){result=true;}
return result;}
function setActive(button,activate){if(activate){button.removeClass('btn-secondary');button.addClass('btn-primary');}
else{button.removeClass('btn-primary');button.addClass('btn-secondary');}}
function updateFilteredList(){$('#market-div>div').each(function(){var hide=false;var dataSource=$(this).data('source');var dataCategory=$(this).data('category');var dataInstalled=$(this).data('installed');if(filterHiddenSrc.indexOf(dataSource)!==-1){hide=true;}
if(filterCategory!==''&&filterCategory!==dataCategory){hide=true;}
if(filterInstalled&&dataInstalled===true){hide=true;}
if(filterNotInstalled&&dataInstalled===false){hide=true;}
if(!hide&&currentSearchValue.length>1){var title=$(this).find('h4').text().toLowerCase();var description=$(this).find('.media-body').text().toLowerCase();if(title.indexOf(currentSearchValue)===-1&&description.indexOf(currentSearchValue)===-1){hide=true;}}
if(hide){$(this).slideUp();}
else{$(this).slideDown();}});}
function refresh(force){pluginsUpdateNeededList=[];var params='list';if(force){params+='-force';}
$('#mass-update').hide();var ajaxData={action:'refresh',params:params,data:sourcesList};ajaxQuery('core/ajax/Market/Ajax/NextDomMarketAjax.php',ajaxData,function(){refreshItems();});}
function refreshItems(){var ajaxData={action:'get',params:'list',data:sourcesList};ajaxQuery('core/ajax/Market/Ajax/NextDomMarketAjax.php',ajaxData,function(result){showItems(result);updateFilteredList();if(pluginsUpdateNeededList.length>0){$('#mass-update').show();$('#mass-update .badge').text(pluginsUpdateNeededList.length);}});}
function showItems(items){var container=$('#market-div');container.empty();for(var index=0;index<items.length;++index){var itemHtmlObj=$(getItemHtml(items[index]));if(items[index]['iconPath']===false){iconDownloadQueue.push([items[index],itemHtmlObj]);}
container.append(itemHtmlObj);}
startIconsDownload();$('.media').click(function(){showPluginModal($(this).data('plugin'),$(this).find('img').attr('src'));return false;});$('.update-marker').click(function(){$('#market-modal-title').text(updateStr);$('#market-modal-content').text(updateThisStr);$('#market-modal-valid').text(updateStr);$('#market-modal').modal('show');currentPlugin=$(this).parent().data('plugin');$('#market-modal-valid').click(function(){updatePlugin(currentPlugin['installedBranchData']['id'],false);});return false;});$('[data-toggle="tooltip"]').tooltip();}
function startIconsDownload(){for(var i=0;i<3;++i){iconDownload();}}
function iconDownload(){var content=iconDownloadQueue.shift();if(typeof content!=='undefined'){var itemData=content[0];var itemObj=content[1];$.post({url:'core/ajax/Market/Ajax/NextDomMarketAjax.php',global:false,data:{action:'get',params:'icon',data:{sourceName:itemData['sourceName'],fullName:itemData['fullName']}},dataType:'json',success:function(iconData,status){if(iconData.state!=='ok'||status!=='success'){notify("Erreur",iconData.result,'error');}
else{var img=new Image();img.src=iconData['result'];itemObj.find('img').attr('src',iconData['result']);if(iconDownloadQueue.length>0){iconDownload();}}},error:function(request,status,error){handleAjaxError(request,status,error);}});}}
function getItemHtml(item){var title=item['name'];if(title!==null){title=title.replace(/([a-z])([A-Z][a-z])/g,'\$1 \$2');}
var pluginData=JSON.stringify(item);pluginData=pluginData.replace(/"/g,'&quot;');var descriptionPar='';if(item['description']==null){item['description']='';}
if(item['description'].length>155){descriptionPar='<p class="truncate">'+item['description'].substr(0,155)+'...</p>';}
else{descriptionPar='<p>'+item['description']+'</p>';}
var iconPath=item['iconPath'];if(item['iconPath']===false){iconPath='public/img/wait_icon.png';}
var result=''+
'<div class="media-container col-xs-12 col-sm-6 col-md-4" data-source="'+item['sourceName']+'" data-category="'+item['category']+'" data-installed="'+item['installed']+'">'+
'<div class="media" data-plugin="'+pluginData+'">';if(item['installed']){result+='<div class="installed-marker"><i data-toggle="tooltip" title="'+installedPluginStr+'" class="fas fa-check"></i></div>';}
if(item['installedBranchData']!==false&&item['installedBranchData']['needUpdate']==true){result+='<div class="update-marker"><i data-toggle="tooltip" title="'+updateAvailableStr+'" class="fas fa-download"></i></div>';pluginsUpdateNeededList.push(item);}
result+=''+
'<h4>'+title+'</h4>'+
'<div class="media-content">'+
'<div class="media-left">'+
'<img src="'+iconPath+'"/>'+
'</div>'+
'<div class="media-body">'+
descriptionPar+
'</div>'+
'</div>'+
'<button>'+moreInformationsStr+'</button>'+
'<div class="gitid">'+item['sourceName']+'</div>'+
'</div>'+
'</div>';return result;}
function showPluginModal(pluginData,iconPath){var modal=$('#md_modal');modal.dialog({title:pluginData['name']});modal.load('index.php?v=d&modal=plugin.Market').dialog('open');currentPlugin=pluginData;currentPlugin['iconPath']=iconPath;}
function updatePlugin(id,massUpdate){var data={action:'update',id:id};ajaxQuery('core/ajax/update.ajax.php',data,function(){var data={action:'refresh',params:'branch-hash',data:[currentPlugin['sourceName'],currentPlugin['fullName']]}
ajaxQuery('core/ajax/Market/Ajax/NextDomMarketAjax.php',data,function(){if(massUpdate&&pluginsUpdateNeededList.length>1){pluginsUpdateNeededList.splice(0,1);currentPlugin=pluginsUpdateNeededList[0];updatePlugin(currentPlugin['installedBranchData']['id'],true);}
else{reloadWithMessage(0);}});});}
function ajaxQuery(url,data,callbackFunc){$.post({url:url,data:data,dataType:'json',success:function(data,status){if(data.state!=='ok'||status!=='success'){notify("Erreur",data.result,'error');}
else{if(typeof callbackFunc!=="undefined"){callbackFunc(data.result);}}},error:function(request,status,error){handleAjaxError(request,status,error);}});}
function reloadWithMessage(messageId){var urlMessageParamIndex=window.location.href.indexOf('message=');if(urlMessageParamIndex===-1){window.location.href=window.location.href+"&message="+messageId;}
else{window.location.href=window.location.href.substr(0,urlMessageParamIndex)+"message="+messageId;}}
