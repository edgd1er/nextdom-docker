<?php

require_once(__DIR__.'/../core/php/core.inc.php');

use NextDom\Managers\CacheManager;

CacheManager::flush();
